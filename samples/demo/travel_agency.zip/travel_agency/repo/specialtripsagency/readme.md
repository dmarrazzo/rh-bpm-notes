JBoss BPMSuite Travel Agency Demo repository
=======================

This is the source repository of the JBoss BPMSuite Travel Agency demo. For the full demo project, including the platform setup and configuration, please refer to: http://www.github.com/jbossdemocentral/bpms-travel-agency-demo 


